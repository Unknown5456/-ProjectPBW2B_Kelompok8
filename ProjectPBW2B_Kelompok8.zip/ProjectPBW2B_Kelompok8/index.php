<?php
session_start();
include 'koneksi.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beasiswa.Id</title>

    <!-- Preconnect & Preload -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="preload" as="image" href="assets/img/background 1.jpg">
    <link rel="preload" as="image" href="assets/img/background 2.jpg">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
        darkMode: 'class'
        }
    </script>
    <style>
    html {
        scroll-behavior: smooth;
    }
</style>
</head>

<body class="bg-gray-300 font-poppins dark:bg-neutral-900 dark:text-white transition duration-100" style="font-family: 'Poppins', sans-serif;">
    <!-- Navbar -->
    <div class="sticky top-0 bg-green-500 dark:bg-zinc-800 transition duration-300 z-50">
        <nav class="flex md:flex-col-3 items-center justify-between px-6 py-4">
            <div class="text-3xl font-bold text-white">
                Beasiswa.Id
            </div>
            <!-- Desktop Menu -->
            <div class="hidden text-white md:flex space-x-12 text-lg font-semibold">
                <a href="#Section-1" class="hover:text-neutral-900 dark:hover:text-emerald-400">Program</a>
                <a href="#Section-2" class="hover:text-neutral-900 dark:hover:text-emerald-400">Persyaratan</a>
                <a href="#Section-3" class="hover:text-neutral-900 dark:hover:text-emerald-400">Benefit</a>
            </div>
            <div class="flex md:flex-col-2 items-center justify-between px-6 py-4">
                <div>
                    <a href="daftar-pendaftar.php" class="text-white px-4 py-3 rounded-lg font-bold hover:text-neutral-900 dark:hover:text-emerald-400">Data Pendaftar</a>
                </div>
                <!-- Dark Mode Button -->
                <div class="hidden md:block ">
                    <button onclick="toggleDarkMode()" id="toggleBtn" class="dark:hidden px-2 py-2">
                        <img src="assets/img/dark_mode_24dp_FFFFFF_FILL1_wght400_GRAD0_opsz24.svg" alt="" id="themeIcon" class="w-6 h-6">
                    </button>
                    <button onclick="toggleDarkMode()" id="toggleBtn" class="hidden dark:block px-2 py-2">
                        <img src="assets/img/light_mode_24dp_FFFFFF_FILL1_wght400_GRAD0_opsz24.svg" alt="" id="themeIcon" class="w-6 h-6">
                    </button>
                </div>
                <!-- Hamburger Menu (Mobile) -->
                <div class="md:hidden">
                    <button id="hamburgerBtn">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                        </svg>
                    </button>
                </div>
            </div>
        </nav>
        <!-- Mobile Slide-In Menu -->
        <div id="mobileMenu" class="fixed top-0 right-0 w-64 h-full bg-white dark:bg-zinc-900 shadow-lg transform translate-x-full transition-transform duration-300 ease-in-out z-50">
            <div class="flex flex-col justify-between h-full px-6 py-8">
            <div>
                <button id="closeBtn" class="mb-8">
                <svg class="w-6 h-6 text-black dark:text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
                </button>
                <nav class="flex flex-col items-center space-y-6 text-lg font-semibold">
                <a href="#Section-1" class="hover:text-emerald-400 mobile-nav-link">Program</a>
                <a href="#Section-2" class="hover:text-emerald-400 mobile-nav-link">Persyaratan</a>
                <a href="#Section-3" class="hover:text-emerald-400 mobile-nav-link">Benefit</a>
                </nav>
            </div>
            <div class="flex justify-center">
                <button onclick="toggleDarkMode()" id="mobileToggleBtn" class="text-black dark:text-white px-4 py-2 rounded-lg font-medium flex items-center gap-2">
                    <!-- Moon Icon (untuk Light Mode) -->
                    <svg id="moonIcon" class="w-5 h-5 dark:hidden" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9 9-4.03 9-9c0-.46-.04-.92-.1-1.36-.98 1.37-2.58 2.26-4.4 2.26-2.98 0-5.4-2.42-5.4-5.4 0-1.81.89-3.42 2.26-4.4-.44-.06-.9-.1-1.36-.1z"/>
                    </svg>
                    <!-- Sun Icon (untuk Dark Mode) -->
                    <svg id="sunIcon" class="w-5 h-5 hidden dark:block" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 2.25a.75.75 0 01.75.75v2.25a.75.75 0 01-1.5 0V3a.75.75 0 01.75-.75zM7.5 12a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0zM18.894 6.166a.75.75 0 00-1.06-1.06l-1.591 1.59a.75.75 0 101.06 1.061l1.591-1.59zM21.75 12a.75.75 0 01-.75.75h-2.25a.75.75 0 010-1.5H21a.75.75 0 01.75.75zM17.834 18.894a.75.75 0 001.06-1.06l-1.59-1.591a.75.75 0 10-1.061 1.06l1.59 1.591zM12 18a.75.75 0 01.75.75V21a.75.75 0 01-1.5 0v-2.25A.75.75 0 0112 18zM7.758 17.303a.75.75 0 00-1.061-1.06l-1.591 1.59a.75.75 0 001.06 1.061l1.591-1.59zM6 12a.75.75 0 01-.75.75H3a.75.75 0 010-1.5h2.25A.75.75 0 016 12zM6.697 7.757a.75.75 0 001.06-1.06l-1.59-1.591a.75.75 0 00-1.061 1.06l1.59 1.591z"/>
                    </svg>
                    <!-- Text yang berubah sesuai mode -->
                    <span id="modeText" class="dark:hidden">Dark Mode</span>
                    <span id="lightModeText" class="hidden dark:block">Light Mode</span>
                </button>
            </div>
            </div>
        </div>
    </div>

    <!-- Hero -->
    <div class="relative text-white py-32 md:py-40 min-h-screen">
    <!-- Background Gambar untuk Light Mode -->
    <div class="absolute inset-0 bg-cover bg-center dark:hidden" style="background-image: url('assets/img/background 1.jpg')"></div>
    <!-- Background Gambar untuk Dark Mode -->
    <div class="absolute inset-0 bg-cover bg-center hidden dark:block" style="background-image: url('assets/img/background 2.jpg')"></div>
    <!-- Overlay hitam -->
    <div class="absolute inset-0 bg-black opacity-60"></div>
    <!-- Konten -->
    <div class="relative z-10 text-center justify-center px-4 md:px-8 max-w-4xl mx-auto">
        <h1 class="text-3xl md:text-5xl font-bold mb-6">
        Wujudkan Mimpimu Raih Pendidikan Berkualitas dengan
        <span class="text-green-400">Beasiswa.Id</span>
        </h1>
        <p class="text-lg">
        Temukan beragam program beasiswa terbaik untuk mendukung perjalanan akademikmu mulai dari prestasi hingga kebutuhan khusus.
        </p>
    </div>
    </div>


    <!-- Section 1 -->
    <div id="Section-1" class="relative -mt-20 px-4 md:px-8 flex flex-col md:flex-row gap-4 md:gap-6 justify-center mb-48">
        <!-- Program 1 -->
        <div class="bg-white md:bg-green-500 md:shadow-green-800 p-6 md:p-8 rounded-2xl shadow-md w-full md:w-1/3">
            <h3 class="text-lg md:text-lg font-bold mb-3 text-black md:text-white text-center">Beasiswa Prestasi</h3>
            <p class="hidden md:block text-justify text-white text-sm md:text-base">Diberikan kepada individu dengan prestasi luar biasa, beasiswa ini memberikan dukungan maksimal untuk terus mengembangkan potensi. Beasiswa ini ditujukan bagi mereka yang memiliki nilai akademik tinggi dan aktif dalam kegiatan kompetisi atau organisasi.</p>
        </div>

        <!-- Program 2 -->
        <div class="bg-white md:bg-green-500 md:shadow-green-800 p-6 md:p-8 rounded-2xl shadow-md w-full md:w-1/3">
            <h3 class="text-lg md:text-lg font-bold mb-3 text-black md:text-white text-center">Beasiswa Akademik</h3>
            <p class="hidden md:block text-white text-sm md:text-base">Ditujukan bagi mahasiswa berprestasi akademik tinggi dengan komitmen belajar yang kuat. Fokus pada bantuan biaya kuliah bagi mahasiswa dengan IPK tinggi dan komitmen akademik yang kuat.</p>
        </div>

        <!-- Program 3 -->
        <div class="bg-white md:bg-green-500 md:shadow-green-800 p-6 md:p-8 rounded-2xl shadow-md w-full md:w-1/3">
            <h3 class="text-lg md:text-lg font-bold mb-3 text-black md:text-white text-center">Beasiswa Non-Akademik</h3>
            <p class="hidden md:block text-white text-sm md:text-base text-justify">Mendukung mahasiswa aktif di bidang seni, olahraga, organisasi, atau kegiatan sosial. Beasiswa ini diberikan kepada siswa atau mahasiswa yang aktif dalam bidang seni, olahraga, kepemimpinan, dan pengabdian masyarakat.</p>
        </div>
    </div>

    <!-- Section 2 -->
    <div id="Section-2" class="bg-white dark:bg-zinc-800 py-24 mb-32">
        <div class="flex flex-col md:flex-row items-center justify-center gap-8 md:gap-24 px-4">
            
            <!-- Gambar - disembunyikan di layar kecil -->
            <div class="hidden md:block flex-shrink-0 w-2/3 sm:w-1/2 md:w-1/3">
                <img src="assets/img/img 1.jpg" alt="img" class="rounded-2xl w-full h-auto">
            </div>

            <!-- Teks -->
            <div class="w-full md:w-1/3 md:bg-green-500 p-6 md:rounded-2xl md:shadow-lg text-black dark:text-white md:text-white text-justify md:text-center md:text-left">
                <h3 class="text-center text-3xl md:text-xl font-medium md:font-semibold mb-8 md:mb-4">Persyaratan</h3>
                <ol class="list-decimal list-inside text-sm md:text-base text-left md:text-left">
                    <li class="mb-4">Merupakan mahasiswa aktif semester 4 </li>
                    <li class="mb-4">Memiliki IPK minimal 3.25</li>
                    <li class="mb-4">Peserta yang mendaftarkan diri tidak boleh menerima beasiswa lainnya</li>
                </ol>
            </div>

        </div>
    </div>

    <!-- Section 3 -->
    <div id="Section-3" class="bg-gradient-to-tr from-emerald-500 to-green-600 py-10 px-4 md:px-8 mb-48">
        <div class="bg-white rounded-3xl shadow-md shadow-green-600 dark:shadow-gray-300 dark:bg-zinc-800 py-8 text-center">
            <!-- Keuntungan Beasiswa Prestasi -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 py-10 px-6 md:px-16">
                <div class="dark:bg-zinc-800 p-6 border-x-0 md:border-x-4 dark:text-white">
                    <div>
                        <h1 class="text-3xl text-center py-2">Beasiswa Prestasi</h1>
                    </div>
                    <div class="flex border-b-2 border-gray-300 w-full mx-auto my-4 text-lg  py-2 ">
                        <div class="w-5 h-5 bg-emerald-500 rounded-full px-1 flex items-center justify-center">
                            <img src="assets/img/centang.png" class="w-full justify-center">
                        </div>
                        <h3 class="px-2 text-left">Bebas biaya pendidikan penuh</h3>
                    </div>
                    <div class="flex border-b-2 border-gray-300 w-full mx-auto my-4 text-lg py-2 ">
                        <div class="w-5 h-5 bg-emerald-500 rounded-full px-1 flex items-center justify-center">
                            <img src="assets/img/centang.png" alt="" class="w-full justify-center" >
                        </div>
                        <h3 class="px-2 text-left">Dana pembinaan prestasi</h3>
                    </div>
                    <div class="flex border-b-2 border-gray-300 w-full mx-auto my-4 text-lg py-2 ">
                        <div class="w-5 h-5 bg-emerald-500 rounded-full px-1 flex items-center justify-center">
                            <img src="assets/img/centang.png" alt="" class="w-full justify-center">
                        </div>
                        <h3 class="px-2 text-left">Kesempatan mewakili lembaga ke ajang nasional/internasional</h3>
                    </div>
                    <div class="flex border-b-2 border-gray-300 w-full mx-auto my-4 text-lg py-2 ">
                        <div class="w-5 h-5 bg-emerald-500 rounded-full px-1 flex items-center justify-center">
                            <img src="assets/img/centang.png" alt="" class="w-full justify-center">
                        </div>
                        <h3 class="px-2 text-left">Akses pelatihan intensif dan pembinaan karakter</h3>
                    </div>
                </div>
                <!-- Keuntungan Beasiswa Akademik -->
                <div class="dark:bg-zinc-800 p-6 rounded-2xl dark:text-white">
                    <div>
                        <h1 class="text-3xl text-center py-2">Beasiswa Akademik</h1>
                    </div>
                    <div class="flex border-b-2 border-gray-300 w-full mx-auto my-4 text-lg  py-2 ">
                        <div class="w-5 h-5 bg-emerald-500 rounded-full px-1 flex items-center justify-center">
                            <img src="assets/img/centang.png" class="w-full justify-center">
                        </div>
                        <h3 class="px-2 text-left">Potongan biaya kuliah hingga 100%</h3>
                    </div>
                    <div class="flex border-b-2 border-gray-300 w-full mx-auto my-4 text-lg py-2 ">
                        <div class="w-5 h-5 bg-emerald-500 rounded-full px-1 flex items-center justify-center">
                            <img src="assets/img/centang.png" alt="" class="w-full justify-center" >
                        </div>
                        <h3 class="px-2 text-left">Tunjangan biaya hidup bulanan</h3>
                    </div>
                    <div class="flex border-b-2 border-gray-300 w-full mx-auto my-4 text-lg py-2 ">
                        <div class="w-5 h-5 bg-emerald-500 rounded-full px-1 flex items-center justify-center">
                            <img src="assets/img/centang.png" alt="" class="w-full justify-center">
                        </div>
                        <h3 class="px-2 text-left">Akses ke jurnal dan seminar ilmiah eksklusif</h3>
                    </div>
                    <div class="flex border-b-2 border-gray-300 w-full mx-auto my-4 text-lg py-2 ">
                        <div class="w-5 h-5 bg-emerald-500 rounded-full px-1 flex items-center justify-center">
                            <img src="assets/img/centang.png" alt="" class="w-full justify-center">
                        </div>
                        <h3 class="px-2 text-left">Bimbingan akademik oleh dosen atau mentor ahli</h3>
                    </div>
                </div>
                <!-- Keuntungan Beasiswa Non-Akademik -->
                <div class="dark:bg-zinc-800 p-6 border-x-0 md:border-x-4 dark:text-white">
                    <div>
                        <h1 class="text-3xl text-center py-2">Beasiswa Non-Akademik</h1>
                    </div>
                    <div class="flex border-b-2 border-gray-300 w-full mx-auto my-4 text-lg  py-2 ">
                        <div class="w-5 h-5 bg-emerald-500 rounded-full px-1 flex items-center justify-center">
                            <img src="assets/img/centang.png" class="w-full justify-center">
                        </div>
                        <h3 class="px-2 text-left">Dana pengembangan minat & bakat</h3>
                    </div>
                    <div class="flex border-b-2 border-gray-300 w-full mx-auto my-4 text-lg py-2 ">
                        <div class="w-5 h-5 bg-emerald-500 rounded-full px-1 flex items-center justify-center">
                            <img src="assets/img/centang.png" alt="" class="w-full justify-center" >
                        </div>
                        <h3 class="px-2 text-left">Pelatihan khusus di bidang non-akademik (workshop, studio, pelatnas)</h3>
                    </div>
                    <div class="flex border-b-2 border-gray-300 w-full mx-auto my-4 text-lg py-2 ">
                        <div class="w-5 h-5 bg-emerald-500 rounded-full px-1 flex items-center justify-center">
                            <img src="assets/img/centang.png" alt="" class="w-full justify-center">
                        </div>
                        <h3 class="px-2 text-left">Dukungan publikasi atau pementasan karya</h3>
                    </div>
                    <div class="flex border-b-2 border-gray-300 w-full mx-auto my-4 text-lg py-2 ">
                        <div class="w-5 h-5 bg-emerald-500 rounded-full px-1 flex items-center justify-center">
                            <img src="assets/img/centang.png" alt="" class="w-full justify-center">
                        </div>
                        <h3 class="px-2 text-left">Kesempatan menjadi duta kegiatan sosial atau kampus</h3>
                    </div>
                </div>
            </div>
            <a href="tahap-1.php" class="bg-emerald-500 hover:bg-emerald-700 text-white px-4 py-3 rounded-lg font-bold">Daftar Sekarang - Gratis!</a>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-zinc-900 text-center py-6 border-t border-gray-700">
        <p class="text-gray-300">© 2023 Beasiswa.Id. All rights reserved.</p>
    </footer>

    <script>
        const html = document.documentElement;
        const hamburgerBtn = document.getElementById('hamburgerBtn');
        const mobileMenu = document.getElementById('mobileMenu');
        const closeBtn = document.getElementById('closeBtn');
        const mobileNavLinks = document.querySelectorAll('.mobile-nav-link');

        // Dark mode functions
        function setTheme(isDark) {
            if (isDark) {
                html.classList.add('dark');
                localStorage.setItem('theme', 'dark');
            } else {
                html.classList.remove('dark');
                localStorage.setItem('theme', 'light');
            }
        }

        function toggleDarkMode() {
            const isDark = html.classList.contains('dark');
            setTheme(!isDark);
        }

        // Mobile menu functions
        function openMobileMenu() {
            mobileMenu.classList.remove('translate-x-full');
            mobileMenu.classList.add('translate-x-0');
        }

        function closeMobileMenu() {
            mobileMenu.classList.remove('translate-x-0');
            mobileMenu.classList.add('translate-x-full');
        }

        // Event listeners
        hamburgerBtn.addEventListener('click', openMobileMenu);
        closeBtn.addEventListener('click', closeMobileMenu);

        // Close mobile menu when clicking navigation links
        mobileNavLinks.forEach(link => {
            link.addEventListener('click', closeMobileMenu);
        });

        // Close mobile menu when clicking outside
        mobileMenu.addEventListener('click', function(e) {
            if (e.target === mobileMenu) {
                closeMobileMenu();
            }
        });

        // Initialize theme on page load
        window.addEventListener('DOMContentLoaded', () => {
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                html.classList.add('dark');
            } else {
                html.classList.remove('dark');
            }
        });

        // Make toggleDarkMode available globally (for onclick attributes)
        window.toggleDarkMode = toggleDarkMode;
    </script>
</body>
</html>