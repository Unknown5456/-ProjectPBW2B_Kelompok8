<?php
session_start();
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['nik'] = $_POST['nik'];
    $_SESSION['nama_lengkap'] = $_POST['nama_lengkap'];
    $_SESSION['alamat'] = $_POST['alamat'];
    $_SESSION['kota_asal'] = $_POST['kota_asal'];
    $_SESSION['kode_pos'] = $_POST['kode_pos'];
    $_SESSION['no_hp'] = $_POST['no_hp'];
    $_SESSION['email'] = $_POST['email'];
    header('Location: tahap-2.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id" id="htmlRoot">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Formulir Beasiswa - Tahap 1</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script> tailwind.config = { darkMode: 'class' };</script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style> body { font-family: 'Poppins', sans-serif; } </style>
</head>
<body class="bg-gray-100 dark:bg-neutral-900 text-black dark:text-white transition duration-300">
  <div class="min-h-screen flex items-center justify-center px-4 py-10">
    <div class="md:w-3/4 w-full bg-white dark:bg-zinc-800 rounded-xl shadow-md p-8">
      <h2 class="text-2xl text-center font-bold mb-4">Formulir Beasiswa</h2>

      <ul class="flex px-4 py-4 gap-8 justify-center text-sm font-medium">
        <li class="flex items-center gap-2">
          <div class="w-6 h-6 flex items-center justify-center rounded-full bg-emerald-500 text-white">1</div>
          <span>Data Diri</span>
        </li>
        <li class="flex items-center gap-2 opacity-60">
          <div class="w-6 h-6 flex items-center justify-center rounded-full border-2 border-gray-300 dark:border-gray-500">2</div>
          <span>Berkas Persyaratan</span>
        </li>
        <li class="flex items-center gap-2 opacity-60">
          <div class="w-6 h-6 flex items-center justify-center rounded-full border-2 border-gray-300 dark:border-gray-500">3</div>
          <span>Persetujuan</span>
        </li>
      </ul>

      <form action="" method="post" class="mt-12 space-y-6">
        <h3 class="text-xl font-semibold mb-6">Data Diri</h3>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label for="nik" class="block mb-2">NIK</label>
            <input type="text" name="nik" id="nik" placeholder="Masukkan NIK" required
              class="w-full p-3 rounded-md border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-zinc-700">
          </div>
          <div>
            <label for="nama_lengkap" class="block mb-2">Nama Lengkap</label>
            <input type="text" name="nama_lengkap" id="nama_lengkap" placeholder="Masukkan Nama" required
              class="w-full p-3 rounded-md border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-zinc-700">
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label for="alamat" class="block mb-2">Alamat</label>
            <input type="text" name="alamat" id="alamat" placeholder="Masukkan Alamat" required
              class="w-full p-3 rounded-md border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-zinc-700">
          </div>
          <div>
            <label for="kota_asal" class="block mb-2">Kota Asal</label>
            <input type="text" name="kota_asal" id="kota_asal" placeholder="Masukkan Kota" required
              class="w-full p-3 rounded-md border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-zinc-700">
          </div>
          <div>
            <label for="kode_pos" class="block mb-2">Kode Pos</label>
            <input type="text" name="kode_pos" id="kode_pos" placeholder="Masukkan Kode Pos" required
              class="w-full p-3 rounded-md border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-zinc-700">
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label for="no_hp" class="block mb-2">No HP</label>
            <input type="text" name="no_hp" id="no_hp" placeholder="Masukkan No HP" required
              class="w-full p-3 rounded-md border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-zinc-700">
          </div>
          <div>
            <label for="email" class="block mb-2">Email</label>
            <input type="email" name="email" id="email" placeholder="Masukkan Email" required
              class="w-full p-3 rounded-md border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-zinc-700">
          </div>
        </div>

        <div class="flex justify-between items-center pt-8">
          <a href="index.php" class="text-sm text-emerald-500 hover:underline">← Kembali ke Halaman Utama</a>
          <button type="submit" class="bg-emerald-500 hover:bg-emerald-700 text-white font-semibold px-6 py-3 rounded-lg">Lanjut</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    const html = document.getElementById('htmlRoot');
    const storedTheme = localStorage.getItem("theme");
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    if (storedTheme === "dark" || (!storedTheme && prefersDark)) {
      html.classList.add("dark");
    }
  </script>
</body>
</html>