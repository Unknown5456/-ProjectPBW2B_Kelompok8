<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_lengkap = $conn->real_escape_string($_POST['nama_lengkap']);
    $email = $conn->real_escape_string($_POST['email']);
    $no_hp = $conn->real_escape_string($_POST['no_hp']);
    $jurusan = $conn->real_escape_string($_POST['jurusan']);
    $ipk = floatval($_POST['ipk']);
    $alasan = $conn->real_escape_string($_POST['alasan']);

    // Validasi IPK
    if ($ipk < 0 || $ipk > 4) {
        die("IPK tidak valid");
    }

    $sql = "INSERT INTO pendaftar (nama_lengkap, email, no_hp, jurusan, ipk, alasan) 
            VALUES ('$nama_lengkap', '$email', '$no_hp', '$jurusan', $ipk, '$alasan')";

    if ($conn->query($sql)) {
        header("Location: hasil.php?nama=" . urlencode($nama_lengkap) . "&ipk=" . $ipk);
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
} else {
    header("Location: pendaftaran.php");
    exit();
}
?>