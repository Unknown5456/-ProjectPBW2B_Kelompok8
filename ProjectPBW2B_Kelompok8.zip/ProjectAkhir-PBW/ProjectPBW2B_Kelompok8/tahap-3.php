<?php
session_start();
include 'koneksi.php';

// Redirect jika data tahap sebelumnya tidak lengkap
if (!isset($_SESSION['nik']) || !isset($_SESSION['jenis_beasiswa']) || !isset($_SESSION['berkas'])) {
    header('Location: tahap-1.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validasi dan simpan file surat persetujuan
    if (isset($_FILES['suratPernyataan'])) {
        $persetujuan = $_FILES['suratPernyataan'];
        
        // Validasi file
        $allowedTypes = ['application/pdf'];
        $maxSize = 2 * 1024 * 1024; // 2MB
        
        if (!in_array($persetujuan['type'], $allowedTypes)) {
            die("Error: File harus berupa PDF.");
        }
        
        if ($persetujuan['size'] > $maxSize) {
            die("Error: Ukuran file maksimal 2MB.");
        }
        
        // Generate nama file unik
        $extension = pathinfo($persetujuan['name'], PATHINFO_EXTENSION);
        $persetujuanName = 'persetujuan_' . uniqid() . '.' . $extension;
        $uploadPath = 'uploads/' . $persetujuanName;
        
        if (move_uploaded_file($persetujuan['tmp_name'], $uploadPath)) {
            // Ambil semua data dari session
            $nik = $_SESSION['nik'];
            $nama = $_SESSION['nama_lengkap'];
            $alamat = $_SESSION['alamat'];
            $kota = $_SESSION['kota_asal'];
            $kodepos = $_SESSION['kode_pos'];
            $hp = $_SESSION['no_hp'];
            $email = $_SESSION['email'];
            $jenis = $_SESSION['jenis_beasiswa'];
            $berkas = $_SESSION['berkas'];
            
            // Ambil dua berkas pertama
            $berkas1 = $berkas['berkas_1'] ?? '';
            $berkas2 = $berkas['berkas_2'] ?? '';
            
            // Simpan ke database menggunakan prepared statement
            $query = "INSERT INTO pendaftar 
                     (nik, nama_lengkap, alamat, kota_asal, kode_pos, no_hp, email, jenis_beasiswa, berkas_1, berkas_2, persetujuan) 
                     VALUES 
                     (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, "sssssssssss", 
                $nik, $nama, $alamat, $kota, $kodepos, $hp, $email, $jenis, 
                $berkas1, $berkas2, $persetujuanName);
            
            if (mysqli_stmt_execute($stmt)) {
                // Bersihkan session dan redirect
                session_destroy();
                header('Location: daftar-pendaftar.php');
                exit;
            } else {
                die("Error: Gagal menyimpan data ke database.");
            }
        } else {
            die("Error: Gagal mengupload file.");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id" id="htmlRoot">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Tahap 3 - Persetujuan</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = { darkMode: 'class' };
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style> body { font-family: 'Poppins', sans-serif; } </style>
</head>
<body class="bg-gray-100 dark:bg-neutral-900 text-black dark:text-white transition duration-300">
  <div class="min-h-screen flex items-center justify-center px-4 py-10">
    <div class="md:w-2/3 w-full bg-white dark:bg-zinc-800 rounded-xl shadow-md p-8" id="formWrapper">
      <h2 class="text-2xl text-center font-bold mb-4">Formulir Beasiswa</h2>
      <ul class="flex justify-center gap-8 mb-8 text-sm font-medium">
        <li class="flex items-center gap-2 opacity-60">
          <div class="w-6 h-6 flex items-center justify-center rounded-full bg-emerald-500 text-white">1</div>
          <span>Data Diri</span>
        </li>
        <li class="flex items-center gap-2 opacity-60">
          <div class="w-6 h-6 flex items-center justify-center rounded-full bg-emerald-500 text-white">2</div>
          <span>Berkas</span>
        </li>
        <li class="flex items-center gap-2">
          <div class="w-6 h-6 flex items-center justify-center rounded-full bg-emerald-500 text-white">3</div>
          <span>Persetujuan</span>
        </li>
      </ul>

      <form class="space-y-6" enctype="multipart/form-data" method="POST">
        <div class="bg-gray-100 dark:bg-zinc-700 p-4 rounded-md border border-gray-300 dark:border-gray-600">
          <p class="text-sm leading-relaxed">
            Dengan ini saya menyatakan bahwa semua informasi dan dokumen yang saya lampirkan adalah benar dan dapat dipertanggungjawabkan. Saya siap menerima sanksi apabila terdapat data yang tidak sesuai.
          </p>
        </div>

        <div>
          <label for="suratPernyataan" class="block mb-2 font-medium">Unggah Surat Pernyataan Keaslian Data (PDF)</label>
          <input type="file" id="suratPernyataan" name="suratPernyataan" accept=".pdf" required
            class="block w-full text-sm text-gray-700 dark:text-white bg-white dark:bg-zinc-700 border border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-emerald-500 file:text-white hover:file:bg-emerald-600" />
          <p class="text-xs mt-1 text-gray-500 dark:text-gray-400">*Format PDF, ukuran maks. 2MB</p>
        </div>

        <label class="inline-flex items-center mt-4">
          <input type="checkbox" required class="form-checkbox text-emerald-600 w-5 h-5 rounded border-gray-300 dark:border-gray-600 bg-white dark:bg-zinc-700 mr-3">
          <span>Saya menyetujui semua persyaratan di atas.</span>
        </label>

        <div class="flex justify-between items-center pt-6">
          <a href="tahap-2.php" class="text-sm text-emerald-500 hover:underline">← Kembali ke Tahap 2</a>
          <button type="submit" name="submit" class="bg-emerald-500 hover:bg-emerald-700 text-white font-semibold px-6 py-3 rounded-lg">Kirim</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    const html = document.getElementById('htmlRoot');
    const storedTheme = localStorage.getItem("theme");
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    if (storedTheme === "dark" || (!storedTheme && prefersDark)) html.classList.add("dark");
  </script>
</body>
</html>