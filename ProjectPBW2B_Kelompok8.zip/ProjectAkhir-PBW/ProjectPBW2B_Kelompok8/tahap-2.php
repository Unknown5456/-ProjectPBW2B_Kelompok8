<?php
session_start();
include 'koneksi.php';

// Redirect jika data tahap 1 belum diisi
if (!isset($_SESSION['nik'])) {
    header('Location: tahap-1.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Simpan jenis beasiswa ke session
    $_SESSION['jenis_beasiswa'] = $_POST['jenis_beasiswa'];
    
    // Buat direktori uploads jika belum ada
    if (!file_exists('uploads')) {
        mkdir('uploads', 0777, true);
    }
    
    // Simpan semua file yang diupload
    $uploadedFiles = [];
    foreach ($_FILES as $key => $file) {
        if ($file['error'] === UPLOAD_ERR_OK) {
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $newName = uniqid() . '.' . $extension;
            move_uploaded_file($file['tmp_name'], 'uploads/' . $newName);
            $uploadedFiles[$key] = $newName;
        }
    }
    
    // Simpan nama file ke session
    $_SESSION['berkas'] = $uploadedFiles;
    
    header('Location: tahap-3.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="id" id="htmlRoot">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Formulir Beasiswa - Tahap 2</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = { darkMode: 'class' };
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Poppins', sans-serif; }
  </style>
</head>
<body class="bg-gray-100 dark:bg-neutral-900 text-black dark:text-white transition duration-300">
  <div class="min-h-screen flex items-center justify-center px-4 py-10">
    <div class="md:w-2/3 w-full bg-white dark:bg-zinc-800 rounded-xl shadow-md p-8">

      <h2 class="text-2xl text-center font-bold mb-1">Formulir Beasiswa</h2>
      <ul class="flex px-4 py-4 gap-8 justify-center">
        <li class="flex items-center gap-2 opacity-60">
            <div class="w-6 h-6 flex items-center justify-center rounded-full bg-emerald-500 text-white">1</div>
            <span>Data Diri</span>
        </li>
        <li class="flex items-center gap-2">
            <div class="w-6 h-6 flex items-center justify-center rounded-full bg-emerald-500 text-white">2</div>
            <span>Berkas Persyaratan</span>
        </li>
        <li class="flex items-center gap-2 opacity-60">
            <div class="w-6 h-6 flex items-center justify-center rounded-full border border-gray-400 dark:border-gray-500">3</div>
            <span>Persetujuan</span>
        </li>
      </ul>

      <form action="" method="post" enctype="multipart/form-data">
        <h3 class="text-xl font-semibold mt-16 mb-4">Berkas Persyaratan</h3>

        <div class="mb-6">
          <label for="jenis_beasiswa" class="block mb-2">Jenis Beasiswa</label>
          <select name="jenis_beasiswa" id="jenis_beasiswa" required class="w-full p-3 rounded-md border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-zinc-700">
            <option value="">-- Pilih Beasiswa --</option>
            <option value="Akademik">Beasiswa Akademik</option>
            <option value="Non-Akademik">Beasiswa Non-Akademik</option>
            <option value="Prestasi">Beasiswa Prestasi</option>
          </select>
        </div>

        <div id="berkas-container" class="space-y-4"></div>

        <div class="flex justify-between mt-6">
          <a href="tahap-1.php" class="text-emerald-500 hover:underline">← Kembali</a>
          <button type="submit" class="bg-emerald-500 hover:bg-emerald-700 text-white font-semibold px-6 py-3 rounded-lg">Lanjut</button>
        </div>
      </form>

    </div>
  </div>

  <script>
    const html = document.getElementById('htmlRoot');
    const storedTheme = localStorage.getItem("theme");
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    const isDark = storedTheme === "dark" || (!storedTheme && prefersDark);
    if (isDark) html.classList.add("dark");

    const jenisBeasiswa = document.getElementById('jenis_beasiswa');
    const berkasContainer = document.getElementById('berkas-container');

    // Daftar berkas sesuai jenis beasiswa
    const berkasList = {
      'Akademik': [
        { name: 'berkas_1', label: 'Transkrip Nilai (PDF)' },
        { name: 'berkas_2', label: 'Sertifikat Prestasi Akademik (PDF/JPG)' }
      ],
      'Non-Akademik': [
        { name: 'berkas_1', label: 'Portofolio (PDF)' },
        { name: 'berkas_2', label: 'Sertifikat Non-Akademik (PDF/JPG)' }
      ],
      'Prestasi': [
        { name: 'berkas_1', label: 'Dokumen Pendukung Prestasi (PDF)' },
        { name: 'berkas_2', label: 'Surat Rekomendasi (PDF)' }
      ]
    };

    // Fungsi untuk menampilkan field berkas
    function tampilkanBerkas(selectedValue) {
      berkasContainer.innerHTML = '';
      if (berkasList[selectedValue]) {
        berkasList[selectedValue].forEach(berkas => {
          const div = document.createElement('div');
          div.innerHTML = `
            <label class="block mb-2" for="${berkas.name}">${berkas.label}</label>
            <input type="file" name="${berkas.name}" id="${berkas.name}" required
              class="block w-full text-sm text-gray-700 dark:text-white bg-white dark:bg-zinc-700 border border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-emerald-500 file:text-white hover:file:bg-emerald-600">
          `;
          berkasContainer.appendChild(div);
        });
      }
    }

    // Tampilkan field saat halaman dimuat jika jenis beasiswa sudah dipilih
    document.addEventListener('DOMContentLoaded', function() {
      if (jenisBeasiswa.value) {
        tampilkanBerkas(jenisBeasiswa.value);
      }
    });

    // Tampilkan field saat jenis beasiswa berubah
    jenisBeasiswa.addEventListener('change', function() {
      tampilkanBerkas(this.value);
    });
  </script>
</body>
</html>