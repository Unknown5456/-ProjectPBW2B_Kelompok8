<?php
include 'koneksi.php';

// Handle delete
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM pendaftar WHERE id=$id");
    header("Location: daftar-pendaftar.php");
    exit;
}

// Ambil semua data
$result = mysqli_query($conn, "SELECT * FROM pendaftar ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="id" id="htmlRoot">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Daftar Pendaftar Beasiswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <script>
        tailwind.config = { darkMode: 'class' };
    </script>
    <style> body { font-family: 'Poppins', sans-serif; } </style>
</head>
<body class="bg-gray-100 dark:bg-neutral-900 text-black dark:text-white transition duration-300">
    <div class="min-h-screen p-6 md:p-12">
        <div class="max-w-6xl mx-auto bg-white dark:bg-zinc-800 rounded-xl shadow-md p-6">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-2xl font-bold">📋 Daftar Pendaftar Beasiswa</h2>
                <a href="tahap-1.php" class="bg-emerald-500 hover:bg-emerald-700 text-white font-semibold px-4 py-2 rounded-lg">+ Tambah</a>
            </div>

            <div class="overflow-x-auto">
                <table class="min-w-full table-auto border-collapse">
                    <thead>
                        <tr class="bg-gray-200 dark:bg-zinc-700 text-left text-sm uppercase">
                            <th class="p-3">No</th>
                            <th class="p-3">NIK</th>
                            <th class="p-3">Nama</th>
                            <th class="p-3">Beasiswa</th>
                            <th class="p-3">Email</th>
                            <th class="p-3">Berkas</th>
                            <th class="p-3 text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="text-sm">
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($result)) : ?>
                        <tr class="border-t border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-zinc-700">
                            <td class="p-3"><?= $no++; ?></td>
                            <td class="p-3"><?= htmlspecialchars($row['nik']); ?></td>
                            <td class="p-3"><?= htmlspecialchars($row['nama_lengkap']); ?></td>
                            <td class="p-3"><?= htmlspecialchars($row['jenis_beasiswa']); ?></td>
                            <td class="p-3"><?= htmlspecialchars($row['email']); ?></td>
                            <td class="p-3 space-y-1">
                                <?php if (!empty($row['berkas_1'])): ?>
                                    <a href="uploads/<?= $row['berkas_1']; ?>" target="_blank" class="text-emerald-500 underline">Berkas 1</a><br>
                                <?php endif; ?>
                                <?php if (!empty($row['berkas_2'])): ?>
                                    <a href="uploads/<?= $row['berkas_2']; ?>" target="_blank" class="text-emerald-500 underline">Berkas 2</a>
                                <?php endif; ?>
                            </td>
                            <td class="p-3 text-center space-x-2">
                                <a href="edit-pendaftar.php?id=<?= $row['id']; ?>" class="inline-flex items-center text-blue-600 hover:text-blue-800">
                                    <i class="ti ti-edit mr-1"></i>Edit
                                </a>
                                <a href="daftar-pendaftar.php?hapus=<?= $row['id']; ?>" onclick="return confirm('Yakin ingin menghapus data ini?')" class="inline-flex items-center text-red-600 hover:text-red-800">
                                    <i class="ti ti-trash mr-1"></i>Hapus
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="text-center mt-8">
            <a href="index.php" class="bg-emerald-500 hover:bg-emerald-700 text-white px-4 py-3 rounded-lg font-bold">Kembali ke Halaman Utama</a>
        </div>
    </div>

    <script>
        const html = document.getElementById('htmlRoot');
        const storedTheme = localStorage.getItem("theme");
        const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
        if (storedTheme === "dark" || (!storedTheme && prefersDark)) html.classList.add("dark");
    </script>
</body>
</html>
