<?php
include 'koneksi.php';

$id = $_GET['id'];

// Cek apakah data dengan ID tersebut ada
$cek = mysqli_query($conn, "SELECT * FROM pendaftar WHERE id = $id");
if (mysqli_num_rows($cek) > 0) {
    $hapus = mysqli_query($conn, "DELETE FROM pendaftar WHERE id = $id");

    if ($hapus) {
        echo "<script>alert('Data berhasil dihapus'); window.location='list_pendaftar.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus data'); window.location='list_pendaftar.php';</script>";
    }
} else {
    echo "<script>alert('Data tidak ditemukan'); window.location='list_pendaftar.php';</script>";
}
?>