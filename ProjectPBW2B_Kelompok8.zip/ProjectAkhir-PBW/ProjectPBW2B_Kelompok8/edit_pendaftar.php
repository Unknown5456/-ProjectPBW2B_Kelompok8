<?php
include 'koneksi.php';
$id = $_GET['id'];
$data = mysqli_query($conn, "SELECT * FROM pendaftar WHERE id=$id");
$row = mysqli_fetch_assoc($data);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $jenis = $_POST['jenis_beasiswa'];
    mysqli_query($conn, "UPDATE pendaftar SET nama_lengkap='$nama', email='$email', jenis_beasiswa='$jenis' WHERE id=$id");
    header("Location: daftar-pendaftar.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id" id="htmlRoot">
<head>
    <meta charset="UTF-8">
    <title>Edit Pendaftar</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script> tailwind.config = { darkMode: 'class' } </script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style> body { font-family: 'Poppins', sans-serif; } </style>
</head>
<body class="bg-gray-100 dark:bg-neutral-900 text-black dark:text-white transition duration-300 px-4 py-10">
    <div class="max-w-xl mx-auto bg-white dark:bg-zinc-800 p-8 rounded-xl shadow-md">
        <h2 class="text-2xl font-bold mb-6 text-center">Edit Data Pendaftar</h2>
        <form method="POST" class="space-y-6">
            <div>
                <label class="block mb-2">Nama Lengkap</label>
                <input type="text" name="nama" value="<?= htmlspecialchars($row['nama_lengkap']) ?>" class="w-full p-3 rounded border dark:bg-zinc-700 dark:border-gray-600" required>
            </div>
            <div>
                <label class="block mb-2">Email</label>
                <input type="email" name="email" value="<?= htmlspecialchars($row['email']) ?>" class="w-full p-3 rounded border dark:bg-zinc-700 dark:border-gray-600" required>
            </div>
            <div>
                <label class="block mb-2">Jenis Beasiswa</label>
                <select name="jenis_beasiswa" class="w-full p-3 rounded border dark:bg-zinc-700 dark:border-gray-600" required>
                    <option <?= $row['jenis_beasiswa'] == 'Akademik' ? 'selected' : '' ?>>Akademik</option>
                    <option <?= $row['jenis_beasiswa'] == 'Non-Akademik' ? 'selected' : '' ?>>Non-Akademik</option>
                    <option <?= $row['jenis_beasiswa'] == 'Prestasi' ? 'selected' : '' ?>>Prestasi</option>
                </select>
            </div>
            <div class="flex justify-between items-center pt-4">
                <a href="daftar-pendaftar.php" class="text-sm text-emerald-500 hover:underline">← Kembali</a>
                <button type="submit" class="bg-emerald-500 hover:bg-emerald-700 text-white px-6 py-2 rounded-lg font-semibold">Simpan Perubahan</button>
            </div>
        </form>
    </div>

    <script>
    const html = document.getElementById('htmlRoot');
    const storedTheme = localStorage.getItem("theme");
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    if (storedTheme === "dark" || (!storedTheme && prefersDark)) html.classList.add("dark");
    </script>
</body>
</html>